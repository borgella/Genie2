/**
 */
package inf5153emf;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Table VPorte</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see inf5153emf.Inf5153emfPackage#getTableVPorte()
 * @model
 * @generated
 */
public interface TableVPorte extends TableVerite {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void update();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void affiche();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void calculer();

} // TableVPorte
