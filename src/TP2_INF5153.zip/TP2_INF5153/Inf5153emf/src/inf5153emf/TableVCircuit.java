/**
 */
package inf5153emf;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Table VCircuit</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see inf5153emf.Inf5153emfPackage#getTableVCircuit()
 * @model
 * @generated
 */
public interface TableVCircuit extends TableVerite {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void update();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void afficher();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void calculer();

} // TableVCircuit
