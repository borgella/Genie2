/**
 */
package inf5153emf;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Obs Porte</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see inf5153emf.Inf5153emfPackage#getObsPorte()
 * @model
 * @generated
 */
public interface ObsPorte extends Observeur {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void update();

} // ObsPorte
