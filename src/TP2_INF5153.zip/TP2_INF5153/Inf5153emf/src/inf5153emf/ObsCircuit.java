/**
 */
package inf5153emf;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Obs Circuit</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see inf5153emf.Inf5153emfPackage#getObsCircuit()
 * @model
 * @generated
 */
public interface ObsCircuit extends Observeur {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void update();

} // ObsCircuit
