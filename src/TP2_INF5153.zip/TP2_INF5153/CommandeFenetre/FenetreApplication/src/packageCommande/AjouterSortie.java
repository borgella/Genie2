package packageCommande;

public class AjouterSortie implements Commande {

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

}
