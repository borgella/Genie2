package packageCommande;

public class AjouterPorteOr implements Commande {

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

}
