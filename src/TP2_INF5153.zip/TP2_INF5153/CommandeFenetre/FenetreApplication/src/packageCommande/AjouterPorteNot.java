package packageCommande;

public class AjouterPorteNot implements Commande {

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

}
