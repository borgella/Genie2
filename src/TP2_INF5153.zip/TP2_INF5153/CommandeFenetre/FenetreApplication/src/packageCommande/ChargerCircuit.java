package packageCommande;

public class ChargerCircuit implements Commande {

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

}
