package packageCommande;

public interface Commande {
	public void execute();

}
