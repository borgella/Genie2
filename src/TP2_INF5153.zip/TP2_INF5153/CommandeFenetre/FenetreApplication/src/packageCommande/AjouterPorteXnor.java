package packageCommande;

public class AjouterPorteXnor implements Commande {

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

}
