package packageCommande;

public class SauvegarderCircuit implements Commande{

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

}
