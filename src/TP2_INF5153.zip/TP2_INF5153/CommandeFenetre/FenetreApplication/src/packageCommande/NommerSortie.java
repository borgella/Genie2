package packageCommande;

public class NommerSortie implements Commande {

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

}
