package packageCommande;

public class AjouterCircuit implements Commande{

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

}
