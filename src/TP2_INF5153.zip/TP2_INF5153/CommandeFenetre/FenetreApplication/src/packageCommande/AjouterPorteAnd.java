package packageCommande;

public class AjouterPorteAnd implements Commande{

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

}
