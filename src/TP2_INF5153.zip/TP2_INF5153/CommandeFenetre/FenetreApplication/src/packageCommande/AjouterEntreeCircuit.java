package packageCommande;

public class AjouterEntreeCircuit implements Commande {

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

}
