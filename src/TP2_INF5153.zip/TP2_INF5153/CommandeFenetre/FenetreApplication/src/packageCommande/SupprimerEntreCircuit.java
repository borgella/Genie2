package packageCommande;

public class SupprimerEntreCircuit implements Commande {

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

}
