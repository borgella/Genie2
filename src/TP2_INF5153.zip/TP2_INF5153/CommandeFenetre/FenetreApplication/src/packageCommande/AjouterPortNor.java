package packageCommande;

public class AjouterPortNor implements Commande {

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

}
