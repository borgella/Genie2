package packageCommande;

public class AjouterPorteXor implements Commande {

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

}
